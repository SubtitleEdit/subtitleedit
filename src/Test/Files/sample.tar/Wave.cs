﻿namespace Nikse.SubtitleEdit.Logic
{
//    class Wave
//    {
//        public Wave(string fileName)
//        {
//            RiffParser parser = new RiffParser();
//            RiffDecodeHeader decoder = new RiffDecodeHeader(parser);
//            parser.OpenFile(fileName);
//            if (RiffParser.ckidAVI == parser.FileType)
//            {
//                decoder.ProcessMainAVI();
//                decoder.ProcessMainWAVE();
//                parser.CloseFile();
//            }
//        }
//    }
}
