﻿namespace Nikse.SubtitleEdit.Logic
{
    public class SpellCheckWord
    {
        public int Index { get; set; }
        public string Text { get; set; }
    }
}
